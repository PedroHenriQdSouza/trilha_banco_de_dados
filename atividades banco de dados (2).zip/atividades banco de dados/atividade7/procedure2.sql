DELIMITER $$

CREATE PROCEDURE sp_aumento_geral_dez_porcento ()
BEGIN
    UPDATE produto
    SET preco = preco * 1.10;
END $$

DELIMITER ;


CALL sp_aumento_geral_dez_porcento();